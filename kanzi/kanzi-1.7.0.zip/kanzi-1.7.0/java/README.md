Build Kanzi
===========

Run 'ant' or 'ant build_compress' to generate a JAR file with compression classes only.

Run 'ant build_lib' to generate a JAR file with all classes in tree excluding tests.

Run 'ant build_all' to generate a JAR file with all classes in tree including tests.

For maven, type 'mvn clean install -DskipTests'

The generated jar file is under 'target'.

